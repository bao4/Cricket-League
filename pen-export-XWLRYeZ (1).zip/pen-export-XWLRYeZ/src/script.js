// GSAP and ScrollTrigger initialization
gsap.registerPlugin(ScrollTrigger);

// Scrolling behavior of sections
gsap.utils.toArray("section").forEach((section, i) => {
  gsap.from(section, {
    opacity: 0,
    y: 50,
    duration: 1,
    scrollTrigger: {
      trigger: section,
      start: "top 80%",
      end: "bottom 20%",
      toggleActions: "play none none reverse"
    }
  });
});

// Parallax effect for header background
gsap.to(".header-bg", {
  y: () => -window.innerHeight * 0.5,
  ease: "none",
  scrollTrigger: {
    trigger: "header",
    start: "top top",
    end: "bottom top",
    scrub: true
  }
});

// Rotating effect for header background
gsap.to(".header-bg", {
  rotation: 360,
  duration: 60,
  repeat: -1,
  ease: "none"
});

// Text animation for h2, p, li
gsap.utils.toArray("h2, p, li").forEach((elem) => {
  gsap.from(elem, {
    opacity: 0,
    y: 20,
    duration: 0.5,
    scrollTrigger: {
      trigger: elem,
      start: "top 90%",
      end: "bottom 10%",
      toggleActions: "play none none reverse"
    }
  });
});

// Cricket ball related selectors
const ball = document.querySelector(".cricket-ball");
const popup = document.querySelector(".popup");
let isPopupVisible = false;

// Function to update popup position
function updatePopupPosition() {
  const ballRect = ball.getBoundingClientRect();
  popup.style.top = `${ballRect.top + ballRect.height / 2}px`;
  popup.style.left = `${ballRect.left + ballRect.width / 2}px`;
}

// Enhanced cricket ball animation
gsap.to(ball, {
  y: () => window.innerHeight - 100,
  ease: "power1.inOut",
  scrollTrigger: {
    trigger: "body",
    start: "top top",
    end: "bottom bottom",
    scrub: 1,
    onUpdate: (self) => {
      gsap.to(ball, {
        rotation: self.progress * 1440,
        duration: 0.1
      });
      gsap.to(ball, {
        x: Math.sin(self.progress * Math.PI * 2) * 50,
        duration: 0.3
      });
      gsap.to(ball, {
        scale: 1 + Math.sin(self.progress * Math.PI * 8) * 0.1,
        duration: 0.2
      });
      if (isPopupVisible) {
        updatePopupPosition();
      }
    }
  }
});

// Bounce effect when ball reaches bottom
ScrollTrigger.create({
  trigger: "body",
  start: "bottom bottom-=100",
  onEnter: () => {
    gsap.to(ball, {
      y: () => window.innerHeight - 120,
      duration: 0.3,
      ease: "bounce.out"
    });
  },
  onLeaveBack: () => {
    gsap.to(ball, {
      y: () => window.innerHeight - 100,
      duration: 0.3,
      ease: "power1.inOut"
    });
  }
});

// Hover effect on ball
ball.addEventListener("mouseenter", () => {
  gsap.to(ball, {
    scale: 1.2,
    duration: 0.3,
    ease: "back.out(1.7)"
  });
});

ball.addEventListener("mouseleave", () => {
  gsap.to(ball, {
    scale: 1,
    duration: 0.3,
    ease: "back.out(1.7)"
  });
});

// Click effect and popup for cricket ball
ball.addEventListener("click", () => {
  isPopupVisible = true;
  updatePopupPosition();

  gsap.to(ball, {
    scale: 0.8,
    duration: 0.1,
    yoyo: true,
    repeat: 1
  });

  gsap.to(popup, {
    display: "block",
    opacity: 1,
    scale: 1,
    duration: 0.3,
    ease: "back.out(1.7)"
  });

  setTimeout(() => {
    gsap.to(popup, {
      opacity: 0,
      scale: 0.8,
      duration: 0.3,
      ease: "power2.in",
      onComplete: () => {
        popup.style.display = "none";
        isPopupVisible = false;
      }
    });
  }, 2000);
});